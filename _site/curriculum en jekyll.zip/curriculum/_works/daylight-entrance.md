---
title: Daylight Entrance
category: Music
category_slug: music
type: music
image: assets/img/works/work8.jpg
music: https://w.soundcloud.com/player/?visual=true&url=http%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F221650664&show_artwork=true
---
