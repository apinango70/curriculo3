 bundle exec jekyll serve


 error webrick en ruby 3
 bundle add webrick